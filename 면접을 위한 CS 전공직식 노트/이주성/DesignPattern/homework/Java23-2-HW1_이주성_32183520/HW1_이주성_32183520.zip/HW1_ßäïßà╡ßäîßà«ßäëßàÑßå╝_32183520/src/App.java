import template.Board3x3Test;

public class App {
    public static void main(String[] args) throws Exception {
//        new template.Board3x3Test();
        new solution.BoardTest();
    }
}
