package solution;

public interface IBoardDisplay {
    void display(Board board);
}
